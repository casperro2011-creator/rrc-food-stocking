RRC Food & Stocking Services - First Website

HOW TO VIEW:
1. Unzip this folder.
2. Open index.html in Chrome, Edge, Firefox, or another web browser.

BEFORE PUBLISHING:
- Replace the phone and email placeholders in index.html.
- Confirm the services and wording match what you actually offer.
- Because the owner is under 18, have a parent/guardian help with any business registration, contracts, payment accounts, or online services that require an adult.

NEXT STEP:
This is a simple first version. It can later be expanded with a logo, photos, service-area information, pricing/request form, and a custom domain.
